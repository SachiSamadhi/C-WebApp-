﻿using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace WebApp
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            // Unity DI
            UnityConfig.RegisterComponents();

            // Enable JSON model binding
            ValueProviderFactories.Factories.Add(new JsonValueProviderFactory());
        }

        // ===== GLOBAL CORS for React frontend =====
        protected void Application_BeginRequest()
        {
            var response = HttpContext.Current.Response;

            // Remove duplicate headers just in case
            response.Headers.Remove("Access-Control-Allow-Origin");

            // Allow your React frontend
            response.AddHeader("Access-Control-Allow-Origin", "http://localhost:3000");

            // Allow headers commonly used in API requests
            response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Accept, Authorization");

            // Allow HTTP methods
            response.AddHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");

            // Handle preflight requests (OPTIONS)
            if (HttpContext.Current.Request.HttpMethod == "OPTIONS")
            {
                response.StatusCode = 200;
                response.End();
            }
        }
    }
}
