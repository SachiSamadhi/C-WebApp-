﻿using WebApp.Models;
using WebApp.Models.RequestApiModels;
using System.Collections.Generic;

namespace WebApp.Interfaces
{
    public interface IEmployee
    {
        // ===== CRUD =====
        Response EmpDetails(UserRequestAPI requestAPI);
        Response Getempbyid(UserRequestAPI requestAPI);
        Response CreateEmployee(UserRequestAPI requestAPI);
        Response UpdateEmployee(UserRequestAPI requestAPI);
        Response DeleteEmployee(int id);

        // ===== DROPDOWN SUPPORT =====
        List<DepartmentModel> GetDepartments();
        List<LocationModel> GetLocationsByDepartment(int deptId);
        List<DesignationModel> GetDesignations();
        List<EducationModel> GetEducations();

        List<HometownModel> GetHometowns();
    }
}
