using System.Web.Mvc;
using Unity;
using Unity.Mvc5;
using WebApp.DataAccess;
using WebApp.Interfaces;

namespace WebApp
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
            var container = new UnityContainer();

            // Register your interfaces and implementations
            container.RegisterType<IEmployee, DAEmployee>();

            // Set the dependency resolver for MVC
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}
