﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Models
{
    public class DepartmentModel
    {
        public int hdd_Department_id { get; set; }

        public string hdd_Department_Name { get; set; }

    }
}