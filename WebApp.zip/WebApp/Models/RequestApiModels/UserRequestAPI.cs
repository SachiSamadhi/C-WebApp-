﻿namespace WebApp.Models.RequestApiModels
{
    public class UserRequestAPI
    {
        public int hed_Employee_id { get; set; }
        public string hed_Employee_Name { get; set; }
        public int hhd_Hometown_id { get; set; }
        public string hed_Employee_Hometown { get; set; }
        public string hed_Phone { get; set; }
        public string hed_Email { get; set; }
        public int hdd_Department_id { get; set; }
        public int hld_location_id { get; set; }
        public int hdd_Designation_id { get; set; }
        public int hed_Education_id { get; set; }
    }
}
