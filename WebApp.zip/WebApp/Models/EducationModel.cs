﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Models
{
    public class EducationModel
    {
        public int hed_Education_id { get; set; }
        public string hed_Education_Name { get; set; }
    }
}
