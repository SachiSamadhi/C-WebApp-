﻿using System;

namespace WebApp.Models
{
    public class HometownModel
    {
        public int hhd_Hometown_id { get; set; }
        public string hhd_Hometown_Name { get; set; }
    }
}
