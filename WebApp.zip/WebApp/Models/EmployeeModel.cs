﻿namespace WebApp.Models
{
    public class EmployeeModel
    {
        // ===== DB FIELDS =====
        public int hed_Employee_id { get; set; }
        public string hed_Employee_Name { get; set; }
        public string hed_Employee_Hometown { get; set; }
        public string hed_Phone { get; set; }
        public string hed_Email { get; set; }

        public int hhd_Hometown_id { get; set; }   // 🔥 REQUIRED
        public int hdd_Department_id { get; set; }
        public int hld_location_id { get; set; }
        public int hdd_Designation_id { get; set; }
        public int hed_Education_id { get; set; }

        public string hdd_Department_Name { get; set; }
        public string hld_location_Name { get; set; }
        public string hed_Designation { get; set; }
        public string hed_Education { get; set; }

        // ===== UI ALIAS =====
        public int EmployeeId => hed_Employee_id;
        public string Name => hed_Employee_Name;
        public string Phone => hed_Phone;
        public string Email => hed_Email;
    }
}
