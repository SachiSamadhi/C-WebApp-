﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Models
{
    public class LocationModel
    {
        public int hld_location_id { get; set; }
        public int hdd_Department_id { get; set; }
        public string hld_location_Name { get; set; }
    }
}