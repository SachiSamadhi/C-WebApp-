﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Models
{
    public class DivisionModel
    {
        public int hdd_Division_id { get; set; }

        public string hdd_Division_Name { get; set; }

    }
}