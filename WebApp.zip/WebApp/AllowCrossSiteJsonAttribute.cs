﻿using System.Web.Mvc;

public class AllowCrossSiteJsonAttribute : ActionFilterAttribute
{
    public override void OnActionExecuting(ActionExecutingContext filterContext)
    {
        var response = filterContext.HttpContext.Response;

        response.AddHeader("Access-Control-Allow-Origin", "http://localhost:3000");
        response.AddHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

        if (filterContext.HttpContext.Request.HttpMethod == "OPTIONS")
        {
            filterContext.Result = new EmptyResult();
            response.StatusCode = 200;
            response.End();
        }

        base.OnActionExecuting(filterContext);
    }
}
