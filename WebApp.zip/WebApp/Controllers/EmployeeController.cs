﻿using System.Web.Mvc;
using WebApp.Interfaces;
using WebApp.Models.RequestApiModels;

namespace WebApp.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployee _employee;

        // ===== Unity will inject DAEmployee here =====
        public EmployeeController(IEmployee employee)
        {
            _employee = employee;
        }

        // ===== GET ALL EMPLOYEES =====
        [HttpGet]
        public ActionResult EmpDetails()
        {
            var result = _employee.EmpDetails(new UserRequestAPI());
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        // ===== GET EMPLOYEE BY ID =====
        [HttpGet]
        public ActionResult Getempbyid(int id)
        {
            var result = _employee.Getempbyid(new UserRequestAPI { hed_Employee_id = id });
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        // ===== CREATE EMPLOYEE =====
        [HttpPost]
        public ActionResult CreateEmployee(UserRequestAPI request)
        {
            if (request == null)
                return Json(new { StatusCode = 400, Result = "Invalid Body" });

            var result = _employee.CreateEmployee(request);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        // ===== UPDATE EMPLOYEE =====
        [HttpPut]
        public ActionResult UpdateEmployee(int id, UserRequestAPI request)
        {
            if (request == null)
                return Json(new { StatusCode = 400, Result = "Invalid Body" });

            request.hed_Employee_id = id;
            var result = _employee.UpdateEmployee(request);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        // ===== DELETE EMPLOYEE =====
        [HttpDelete]
        public ActionResult DeleteEmployee(int id)
        {
            var result = _employee.DeleteEmployee(id);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        // ===== DROPDOWN ENDPOINTS =====
        [HttpGet]
        public ActionResult GetDepartments()
        {
            var result = _employee.GetDepartments();
            return Json(new { StatusCode = 200, ResultSet = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetLocationsByDepartment(int deptId)
        {
            var result = _employee.GetLocationsByDepartment(deptId);
            return Json(new { StatusCode = 200, ResultSet = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetDesignations()
        {
            var result = _employee.GetDesignations();
            return Json(new { StatusCode = 200, ResultSet = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetEducations()
        {
            var result = _employee.GetEducations();
            return Json(new { StatusCode = 200, ResultSet = result }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetHometowns()
        {
            var result = _employee.GetHometowns();
            return Json(new { StatusCode = 200, ResultSet = result }, JsonRequestBehavior.AllowGet);
        }
    }
}
