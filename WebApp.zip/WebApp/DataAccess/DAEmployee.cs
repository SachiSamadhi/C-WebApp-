﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using WebApp.DatabaseConnectivity;
using WebApp.Interfaces;
using WebApp.Models;
using WebApp.Models.RequestApiModels;

namespace WebApp.DataAccess
{
    public class DAEmployee : IEmployee
    {
        // ================= GET ALL EMPLOYEES =================
        public Response EmpDetails(UserRequestAPI requestAPI)
        {
            Response res = new Response();
            List<EmployeeModel> empList = new List<EmployeeModel>();

            string Query = @"
                SELECT 
                    e.hed_Employee_id,
                    e.hed_Employee_Name,
                    h.hhd_Hometown_Name AS hed_Employee_Hometown,
                    dpt.hdd_Department_Name AS hdd_Department_Name,
                    loc.hld_location_Name AS hld_location_Name,
                    des.hdd_Designation_Name AS hed_Designation,
                    edu.hed_Education_Name AS hed_Education,
                    e.hed_Phone,
                    e.hed_Email
                FROM HRM_Employee_Details e
                LEFT JOIN HRM_Hometown_Details h ON e.hhd_Hometown_id = h.hhd_Hometown_id
                LEFT JOIN HRM_Department_Details dpt ON e.hdd_Department_id = dpt.hdd_Department_id
                LEFT JOIN HRM_Location_Details loc ON e.hld_location_id = loc.hld_location_id
                LEFT JOIN HRM_Designation_Details des ON e.hdd_Designation_id = des.hdd_Designation_id
                LEFT JOIN HRM_Education_Details edu ON e.hed_Education_id = edu.hed_Education_id
            ";

            using (var db = new DBconnect())
            {
                try
                {
                    using (SqlDataReader reader = db.ReadTable(Query))
                    {
                        while (reader.Read())
                        {
                            empList.Add(new EmployeeModel
                            {
                                hed_Employee_id = Convert.ToInt32(reader["hed_Employee_id"]),
                                hed_Employee_Name = reader["hed_Employee_Name"]?.ToString() ?? "",
                                hed_Employee_Hometown = reader["hed_Employee_Hometown"]?.ToString() ?? "",
                                hed_Phone = reader["hed_Phone"] != DBNull.Value ? reader["hed_Phone"].ToString() : "",
                                hed_Email = reader["hed_Email"] != DBNull.Value ? reader["hed_Email"].ToString() : "",
                                hdd_Department_Name = reader["hdd_Department_Name"]?.ToString() ?? "",
                                hld_location_Name = reader["hld_location_Name"]?.ToString() ?? "",
                                hed_Designation = reader["hed_Designation"]?.ToString() ?? "",
                                hed_Education = reader["hed_Education"]?.ToString() ?? ""
                            });
                        }
                    }

                    res.StatusCode = 200;
                    res.ResultSet = empList;
                }
                catch (Exception ex)
                {
                    res.StatusCode = 500;
                    res.Result = ex.Message;
                }
            }

            return res;
        }

        // ================= GET EMPLOYEE BY ID =================
        public Response Getempbyid(UserRequestAPI requestAPI)
        {
            Response res = new Response();
            List<EmployeeModel> empList = new List<EmployeeModel>();

            string Query =  @"
SELECT 
    e.hed_Employee_id,
    e.hed_Employee_Name,
    e.hed_Phone,
    e.hed_Email,

    e.hhd_Hometown_id,
    h.hhd_Hometown_Name,

    e.hdd_Department_id,
    dpt.hdd_Department_Name,

    e.hld_location_id,
    loc.hld_location_Name,

    e.hdd_Designation_id,
    des.hdd_Designation_Name,

    e.hed_Education_id,
    edu.hed_Education_Name
FROM HRM_Employee_Details e
LEFT JOIN HRM_Hometown_Details h ON e.hhd_Hometown_id = h.hhd_Hometown_id
LEFT JOIN HRM_Department_Details dpt ON e.hdd_Department_id = dpt.hdd_Department_id
LEFT JOIN HRM_Location_Details loc ON e.hld_location_id = loc.hld_location_id
LEFT JOIN HRM_Designation_Details des ON e.hdd_Designation_id = des.hdd_Designation_id
LEFT JOIN HRM_Education_Details edu ON e.hed_Education_id = edu.hed_Education_id
WHERE e.hed_Employee_id = @EmployeeId
";


            using (var db = new DBconnect())
            using (var cmd = new SqlCommand(Query, db.GetOpenConnection()))
            {
                try
                {
                    cmd.Parameters.AddWithValue("@EmployeeId", requestAPI.hed_Employee_id);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            empList.Add(new EmployeeModel
                            {
                                hed_Employee_id = Convert.ToInt32(reader["hed_Employee_id"]),
                                hed_Employee_Name = reader["hed_Employee_Name"].ToString(),
                                hed_Phone = reader["hed_Phone"].ToString(),
                                hed_Email = reader["hed_Email"].ToString(),

                                hhd_Hometown_id = Convert.ToInt32(reader["hhd_Hometown_id"]),
                                hdd_Department_id = Convert.ToInt32(reader["hdd_Department_id"]),
                                hld_location_id = Convert.ToInt32(reader["hld_location_id"]),
                                hdd_Designation_id = Convert.ToInt32(reader["hdd_Designation_id"]),
                                hed_Education_id = Convert.ToInt32(reader["hed_Education_id"])
                            });

                        }
                    }

                    res.StatusCode = 200;
                    res.ResultSet = empList;
                }
                catch (Exception ex)
                {
                    res.StatusCode = 500;
                    res.Result = ex.Message;
                }
            }

            return res;
        }

        // ================= CREATE EMPLOYEE =================
        public Response CreateEmployee(UserRequestAPI requestAPI)
        {
            Response res = new Response();

            using (var db = new DBconnect())
            using (var conn = db.GetOpenConnection())
            {
                try
                {
                    string insertQuery = @"
                        INSERT INTO HRM_Employee_Details
                        (
                            hed_Employee_Name,
                            hed_Employee_Hometown,
                            hed_Phone,
                            hed_Email,
                            hdd_Department_id,
                            hld_location_id,
                            hdd_Designation_id,
                            hed_Education_id,
                            hhd_Hometown_id
                        )
                        VALUES
                        (
                            @Name, @Hometown, @Phone, @Email,
                            @DepartmentId, @LocationId, @DesignationId, @EducationId, @HometownId
                        )
                    ";

                    using (var cmd = new SqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", requestAPI.hed_Employee_Name ?? "");
                        cmd.Parameters.AddWithValue("@Hometown", requestAPI.hed_Employee_Hometown ?? "");
                        cmd.Parameters.AddWithValue("@Phone", requestAPI.hed_Phone ?? "");
                        cmd.Parameters.AddWithValue("@Email", requestAPI.hed_Email ?? "");
                        cmd.Parameters.AddWithValue("@DepartmentId", requestAPI.hdd_Department_id);
                        cmd.Parameters.AddWithValue("@LocationId", requestAPI.hld_location_id);
                        cmd.Parameters.AddWithValue("@DesignationId", requestAPI.hdd_Designation_id);
                        cmd.Parameters.AddWithValue("@EducationId", requestAPI.hed_Education_id);
                        cmd.Parameters.AddWithValue("@HometownId", requestAPI.hhd_Hometown_id);

                        cmd.ExecuteNonQuery();
                    }

                    res.StatusCode = 200;
                    res.Result = "Employee created successfully";
                }
                catch (Exception ex)
                {
                    res.StatusCode = 500;
                    res.Result = ex.Message;
                }
            }

            return res;
        }

        // ================= UPDATE EMPLOYEE =================
        public Response UpdateEmployee(UserRequestAPI request)
        {
            Response res = new Response();
            string query = @"
                UPDATE HRM_Employee_Details
                SET
                    hed_Employee_Name = @Name,
                    hed_Employee_Hometown = @Hometown,
                    hhd_Hometown_id = @HometownId,
                    hed_Phone = @Phone,
                    hed_Email = @Email,
                    hdd_Department_id = @DepartmentId,
                    hld_location_id = @LocationId,
                    hdd_Designation_id = @DesignationId,
                    hed_Education_id = @EducationId
                WHERE hed_Employee_id = @EmployeeId
            ";

            using (var db = new DBconnect())
            using (var conn = db.GetOpenConnection())
            using (var cmd = new SqlCommand(query, conn))
            {
                try
                {
                    cmd.Parameters.AddWithValue("@EmployeeId", request.hed_Employee_id);
                    cmd.Parameters.AddWithValue("@Name", request.hed_Employee_Name ?? "");
                    cmd.Parameters.AddWithValue("@Hometown", request.hed_Employee_Hometown ?? "");
                    cmd.Parameters.AddWithValue("@HometownId", request.hhd_Hometown_id);
                    cmd.Parameters.AddWithValue("@Phone", request.hed_Phone ?? "");
                    cmd.Parameters.AddWithValue("@Email", request.hed_Email ?? "");
                    cmd.Parameters.AddWithValue("@DepartmentId", request.hdd_Department_id);
                    cmd.Parameters.AddWithValue("@LocationId", request.hld_location_id);
                    cmd.Parameters.AddWithValue("@DesignationId", request.hdd_Designation_id);
                    cmd.Parameters.AddWithValue("@EducationId", request.hed_Education_id);

                    cmd.ExecuteNonQuery();
                    res.StatusCode = 200;
                    res.Result = "Employee updated successfully";
                }
                catch (Exception ex)
                {
                    res.StatusCode = 500;
                    res.Result = ex.Message;
                }
            }

            return res;
        }

        // ================= DELETE EMPLOYEE =================
        public Response DeleteEmployee(int id)
        {
            Response res = new Response();
            string query = "DELETE FROM HRM_Employee_Details WHERE hed_Employee_id = @EmployeeId";

            using (var db = new DBconnect())
            using (var conn = db.GetOpenConnection())
            using (var cmd = new SqlCommand(query, conn))
            {
                try
                {
                    cmd.Parameters.AddWithValue("@EmployeeId", id);
                    cmd.ExecuteNonQuery();
                    res.StatusCode = 200;
                    res.Result = "Employee deleted successfully";
                }
                catch (Exception ex)
                {
                    res.StatusCode = 500;
                    res.Result = ex.Message;
                }
            }

            return res;
        }

        // ================= DROPDOWN METHODS =================
        public List<DepartmentModel> GetDepartments()
        {
            List<DepartmentModel> list = new List<DepartmentModel>();
            string query = "SELECT hdd_Department_id, hdd_Department_Name FROM HRM_Department_Details";
            using (var db = new DBconnect())
            using (var reader = db.ReadTable(query))
            {
                while (reader.Read())
                {
                    list.Add(new DepartmentModel
                    {
                        hdd_Department_id = Convert.ToInt32(reader["hdd_Department_id"]),
                        hdd_Department_Name = reader["hdd_Department_Name"].ToString()
                    });
                }
            }
            return list;
        }

        public List<LocationModel> GetLocationsByDepartment(int deptId)
        {
            List<LocationModel> list = new List<LocationModel>();
            string query = "SELECT hld_location_id, hdd_Department_id, hld_location_Name FROM HRM_Location_Details WHERE hdd_Department_id=@id";

            using (var db = new DBconnect())
            using (var cmd = new SqlCommand(query, db.GetOpenConnection()))
            {
                cmd.Parameters.AddWithValue("@id", deptId);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        list.Add(new LocationModel
                        {
                            hld_location_id = Convert.ToInt32(reader["hld_location_id"]),
                            hdd_Department_id = Convert.ToInt32(reader["hdd_Department_id"]),
                            hld_location_Name = reader["hld_location_Name"].ToString()
                        });
                    }
                }
            }

            return list;
        }

        public List<DesignationModel> GetDesignations()
        {
            List<DesignationModel> list = new List<DesignationModel>();
            string query = "SELECT hdd_Designation_id, hdd_Designation_Name FROM HRM_Designation_Details";
            using (var db = new DBconnect())
            using (var reader = db.ReadTable(query))
            {
                while (reader.Read())
                {
                    list.Add(new DesignationModel
                    {
                        hdd_Designation_id = Convert.ToInt32(reader["hdd_Designation_id"]),
                        hdd_Designation_Name = reader["hdd_Designation_Name"].ToString()
                    });
                }
            }
            return list;
        }

        public List<EducationModel> GetEducations()
        {
            List<EducationModel> list = new List<EducationModel>();
            string query = "SELECT hed_Education_id, hed_Education_Name FROM HRM_Education_Details";
            using (var db = new DBconnect())
            using (var reader = db.ReadTable(query))
            {
                while (reader.Read())
                {
                    list.Add(new EducationModel
                    {
                        hed_Education_id = Convert.ToInt32(reader["hed_Education_id"]),
                        hed_Education_Name = reader["hed_Education_Name"].ToString()
                    });
                }
            }
            return list;
        }

        public List<HometownModel> GetHometowns()
        {
            List<HometownModel> list = new List<HometownModel>();
            string query = "SELECT hhd_Hometown_id, hhd_Hometown_Name FROM HRM_Hometown_Details";
            using (var db = new DBconnect())
            using (var reader = db.ReadTable(query))
            {
                while (reader.Read())
                {
                    list.Add(new HometownModel
                    {
                        hhd_Hometown_id = Convert.ToInt32(reader["hhd_Hometown_id"]),
                        hhd_Hometown_Name = reader["hhd_Hometown_Name"].ToString()
                    });
                }
            }
            return list;
        }
    }
}
